package tests;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

import tubeVideosManager.Genre;
import tubeVideosManager.Playlist;
import tubeVideosManager.TubeVideosManager;
import tubeVideosManager.Video;

/**
 * 
 * You need student tests if you are asking for help during
 * office hours about bugs in your code. Feel free to use
 * tools available in TestingSupport.java
 * 
 * @author UMCP CS Department
 *
 */
public class StudentTests {

	@Test
	public void videoGets() {
		Video video = new Video("Cute kittens play with even cuter puppies", "www.tooCute.com", 12, Genre.Documentary);
		
		assertEquals(video.getTitle(), "Cute kittens play with even cuter puppies");
		assertEquals(video.getUrl(), "www.tooCute.com");
		assertEquals(video.getDurationInMinutes(), 12);
		assertEquals(video.getGenre(), Genre.Documentary);
		
	}
	@Test
	public void videoCompareTo() {
		Video video1 = new Video("Cute kittens play with even cuter puppies", "www.tooCute.com", 12, Genre.Documentary);
		Video video2 = new Video("Rush Hour", "httpsmoviesThatAgedTerribly.org", 128, Genre.Comedy);
		
		System.out.println(video1.getTitle());
		System.out.println(video2.getTitle());
		System.out.println(video1.compareTo(video2));
		
		assertEquals(video1.compareTo(video2), -15);
		
	}
	@Test
	public void videoEquals() {
		Video video1 = new Video("Rush Hour", "httpsmoviesThatAgedTerribly.org", 128, Genre.Comedy);
		Video video2 = new Video("Rush Hour", "httpsmoviesThatAgedTerribly.com", 23, Genre.Comedy);
		
		assertTrue(video1.equals(video2));
	}
	@Test
	public void addCommentsFindVideo() {
		Video video2 = new Video("Rush Hour", "httpsmoviesThatAgedTerribly.org", 128, Genre.Comedy);
		
		video2.addComments("Hey guys");
		
		TubeVideosManager t = new TubeVideosManager();
		t.addVideoToDB("Rush Hour", "httpsmoviesThatAgedTerribly.org", 128, Genre.Comedy);
		t.addComments("Rush Hour", "Hey!");
		
		System.out.println(t.findVideo("Rush Hour").getComments());
		assertEquals(t.findVideo("Rush Hour").getComments().toString(), "[Hey!]");
	}
	
	@Test
	public void compareToVid() {
		Video video1 = new Video("Rush Hour3", "httpsmoviesThatAgedTerribly.org", 128, Genre.Comedy);
		Video video2 = new Video("Rush Hour3", "httpsmoviesThatAgedTerribly.org", 128, Genre.Comedy);
		Video video3 = new Video("Final", "httpsmoviesThatAgedTerribly.org", 128, Genre.Comedy);
		
		System.out.println(video1.compareTo(video3));
		assertEquals(video1.compareTo(video3),12);
	}
	
	/*  Playlist   */
	
	@Test
	public void getPlaylistVideoTitles() {
		Playlist playlist = new Playlist("Yup");
		
		playlist.addToPlaylist("Scream");
		playlist.addToPlaylist("Rush Hour3");
		playlist.addToPlaylist("Pretty Women");
		playlist.addToPlaylist("Coco");
		playlist.addToPlaylist("Rush Hour3");
		
		System.out.println(playlist.getPlaylistVideosTitles());
		assertEquals(playlist.getPlaylistVideosTitles().toString(), "[Scream, Rush Hour3, Pretty Women, Coco, Rush Hour3]");
	}
	@Test
	public void removePlaylistGetPlayVT() {
		Playlist playlist = new Playlist("Weirdo");
		
		playlist.addToPlaylist("Scream");
		playlist.addToPlaylist("Rush Hour3");
		playlist.addToPlaylist("Pretty Women");
		playlist.addToPlaylist("Coco");
		playlist.addToPlaylist("Rush Hour3");
		
		System.out.println(playlist.getPlaylistVideosTitles());
		
		playlist.removeFromPlaylistAll("Rush Hour3");
		
		System.out.println(playlist.getPlaylistVideosTitles());
		assertFalse(playlist.removeFromPlaylistAll("Rush Hour3"));
		assertEquals(playlist.getPlaylistVideosTitles().toString(), "[Scream, Pretty Women, Coco]");
		
	}
	@Test
	public void getAddToPlaylistName() {
		TubeVideosManager t = new TubeVideosManager();
		t.addVideoToDB("Rush Hour3", "httpsmoviesThatAgedTerribly.org", 128, Genre.Comedy);
		t.addVideoToDB("Rush Hour", "httpsmoviesThatAgedTerribly.org", 128, Genre.Comedy);
		t.addVideoToDB("Final", "httpsmoviesThatAgedTerribly.org", 128, Genre.Comedy);
		t.addVideoToDB("Rapunzel", "httpsmoviesThatAgedTerribly.org", 128, Genre.Comedy);
		
		t.addPlaylist("Rush Hour3");
		t.addPlaylist("Coco");
		t.addPlaylist("Rogue");
		System.out.println(Arrays.toString(t.getPlaylistsNames()));
		
		assertEquals(Arrays.toString(t.getPlaylistsNames()), "[Rush Hour3, Coco, Rogue]");
	}
	
	/* TubeVideosManager */
	
	@Test
	public void addVideoToPlaylistTest() {
		Playlist playlist = new Playlist("Weird");
		playlist.addToPlaylist("Scream");
		playlist.addToPlaylist("Rush Hour3");
		playlist.addToPlaylist("Pretty Women");
		playlist.addToPlaylist("Coco");
		playlist.addToPlaylist("Rush Hour3");
		TubeVideosManager t = new TubeVideosManager();
		
		t.addVideoToPlaylist("Cute", playlist.getName());
		
		assertFalse(t.addVideoToPlaylist("Final", "Weird"));
	}
	
}

