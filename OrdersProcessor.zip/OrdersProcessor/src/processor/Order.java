package processor;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

public class Order implements Runnable{
	HashMap<String, Integer> quantityKeeper;
	HashMap<String, Double> prices;
	TreeMap<Integer, String> clientInfo;
	
	//For summary
	TreeMap<String, Integer> itemCount;
	HashMap<String, Double> itemRevenue;

	String summary;
	int customerId;
	int quantity;
	Double price;
	Double bill;
	Double totalCost;
	File file;

	public Order(String fileName, HashMap<String, Double> prices, TreeMap<Integer, String> clientInfo,
			TreeMap<String, Integer> itemCount, HashMap<String, Double> itemRevenue) {
		file = new File(fileName);
		quantityKeeper = new HashMap<>();
		this.itemRevenue = itemRevenue;
		this.itemCount = itemCount;
		this.prices = prices;
		this.clientInfo = clientInfo;

		customerId = 0;
		quantity = 0;
		summary = "";
		price = 0.0;
		bill = 0.0;
	}
	 
	@Override
	public void run() {
		if(file != null) {

			try (Scanner scan = new Scanner(file)){
				scan.next();
				customerId = scan.nextInt();
			//	System.out.println("Reading order for client with id: " + customerId);

				summary += "----- Order details for client with Id: " + customerId + " -----\n";

				while(scan.hasNextLine()) {
					String item = scan.next();
					scan.next();

					if(quantityKeeper.containsKey(item)) {
						bill += prices.get(item);
						int local = quantityKeeper.get(item) + 1;
						quantityKeeper.put(item, local);

					} else {
						bill += prices.get(item);
						quantityKeeper.put(item, 1);
					}
					
					synchronized(itemCount) {
						if(itemCount.containsKey(item)) {
							itemCount.put(item, itemCount.get(item) + 1);
						} else {
							itemCount.put(item, 1);
						}
					}
					
					synchronized(itemRevenue) {
						if(itemRevenue.containsKey(item)) {
							itemRevenue.put(item, itemRevenue.get(item) + price);
						} else {
							itemRevenue.put(item, price);
						}
					}

				}
				ArrayList<String> sortedItems = new ArrayList<String>(quantityKeeper.keySet());
				Collections.sort(sortedItems);

				for(String item : sortedItems) {
					quantity = quantityKeeper.get(item);
					price = prices.get(item);
					totalCost = price * quantity;

					summary += "Item's name: " + item + ", Cost per item: " + NumberFormat.getCurrencyInstance().format(price)
					+ ", Quantity: " + quantity + ", Cost: " + NumberFormat.getCurrencyInstance().format(totalCost) + "\n";
				}

				summary += "Order Total: " + NumberFormat.getCurrencyInstance().format(bill) + "\n";
				System.out.println(summary);

				
				synchronized(clientInfo) {
					if(summary.length() == 0) {
						System.out.println("Summary is Empty for client " + customerId);
						
					} else {
						clientInfo.put(customerId, summary);
					}
					
				}

				
				scan.close();

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}
}
