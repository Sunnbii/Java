package processor;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class OrdersProcessor {
	private HashMap<String, Double> prices = new HashMap<>();
	private int clientID;
	
	//Write everything over to a file, takes Client's num and gives back order
	private TreeMap<Integer, String> clientInfo = new TreeMap<>();
	TreeMap<String, Integer> totalItemCount = new TreeMap<String, Integer>();
	HashMap<String, Double> totalItemRevenue = new HashMap<String, Double>();
	
	public void run() {
		Double overallCost = 0.0;

		Scanner scan = new Scanner(System.in);

		System.out.print("Enter item's data file name: ");
		String fileName = scan.next();
		File file = new File(fileName);

		//COME BACK TO THIS
		System.out.print("Enter 'y' for multiple threads, any other character otherwise: ");
		String threadInput = scan.next();

		System.out.print("Enter number of orders to process: ");
		int ordersNum = scan.nextInt();

		System.out.print("Enter order's base filename: ");
		String base = scan.next();

		System.out.print("Enter result's filename: ");
		String resultFileName = scan.next();

		long startTime = System.currentTimeMillis();

		try (Scanner scanDataFile = new Scanner(file)){

			while(scanDataFile.hasNext()) {
				String item = scanDataFile.next();
				Double cost = scanDataFile.nextDouble();
				prices.put(item, cost);
			} 
			scanDataFile.close();

		} catch (FileNotFoundException e) {
			System.err.println("Could not find file: " + file);
		}

		Thread[] threads = new Thread[ordersNum];

		//Creates threads
		
		for(int i = 1; i <= ordersNum; i++) {
			Order order = new Order(base + i + ".txt", prices, clientInfo, totalItemCount, totalItemRevenue);
			threads[i - 1] = new Thread(order);
		}	

		if(threadInput.equalsIgnoreCase("y")) {
			for(Thread t : threads) {
				if(t != null) {
					t.start();
				} else {
					System.out.print("START thread null");
				}

			}
			for(Thread t : threads) {
				try {
					if(t != null) {
						t.join();
					} else {
						System.out.print("JOIN thread is null");
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} else {
			for(Thread t : threads) {
				// So it runs in sequential order
				if(t != null) {
					t.run();
				}
			}
		}
		System.out.println("Stopping here?");
		try (PrintWriter writer = new PrintWriter(resultFileName)){
			double summaryTotal = 0.0;

			for(Map.Entry<Integer, String> entry : clientInfo.entrySet()) {
				writer.print(entry.getValue());
			}

			writer.print("***** Summary of all orders *****\n");

			for(String item : totalItemCount.keySet()) {
				int quantity = totalItemCount.get(item);
				double price = prices.get(item);
				double revenue = quantity * price;
				summaryTotal += revenue;

				writer.print("Summary - Item's name: " + item + ", Cost per item: " + NumberFormat.getCurrencyInstance().format(price)
						+ ", Number sold: " + quantity + ", Item's Total: " + NumberFormat.getCurrencyInstance().format(revenue) + "\n");
			}
			writer.print("Summary Grand Total: " + NumberFormat.getCurrencyInstance().format(summaryTotal) + "\n");

			writer.close();

		} catch (Exception e) {
			System.err.println("Error writing file");
		}

		long endTime = System.currentTimeMillis();
		System.out.println("Processing time (msec): " + (endTime - startTime));
		System.out.println("Results can be found in " + resultFileName);	

		scan.close();
	} 

	public static void main(String[] args) {
		OrdersProcessor process = new OrdersProcessor();
		process.run();
	
	}


}