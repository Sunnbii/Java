#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sysexits.h>
#include <ctype.h>
#include "document.h"

//Write test for invalid cases
// Should exit w/ ctrl + D

int main(int argc, char *argv[]){
    FILE *user_input;
    Document doc, *tmp;
    char buffer[MAX_STR_SIZE + 1], buffer2[MAX_STR_SIZE + 1], buffer3[MAX_STR_SIZE + 1], valid[1024] = {'\0'}, command[MAX_STR_SIZE + 1] = {'\0'}, tmp_buff[1024];
    int para_num, line_num, i, count, length;
    void *extra = &buffer;
    

    /* Initializing document */
    tmp = &doc;
    init_document(tmp, "main_document");

    /* Setting up stream */
    if(argc > 2){
        printf("Usage: user_interface\nUsage: user_interface <filename>\n");
        exit(EX_USAGE);
    } else if(argc == 2){
        user_input = fopen(argv[1], "r");

        if(user_input == NULL){
            user_input = stdin;
            fprintf(stdout, "Invalid Command\n");
        }
    } else {
        user_input = stdin;
    }
    
        while(feof(user_input) == 0){ 
            strcpy(command, ""); 
            strcpy(valid, "");
            
            if(user_input == stdin){
                fprintf(stdout, "> ");
            }
            
            fgets(valid, 1024, user_input);
            strcpy(tmp_buff, valid);

            if(isspace(valid[0]) > 0){
                count = 0;
                length = strlen(valid);
                while(count < length){
                    if(isalpha(valid[count]) > 0){
                        strcpy(valid, tmp_buff + count);
                        break;
                    }
                count++;
            }
        }
            i = sscanf(valid, "%s", command);

            if(strcmp(command, "add_line_after") == 0){
               i = sscanf(valid + strlen(command), "%d %d %s", &para_num, &line_num, buffer);

                if(para_num <= 0 || line_num < 0  || i != 3 || isalpha(para_num) > 0 || 
                isalpha(line_num) > 0 || buffer[0] != '*'){
                    fprintf(stdout, "Invalid Command\n");
                    continue;
                }

                count = strlen(command);
                length = strlen(valid);
                while(count < length){
                    if(valid[count] == '*'){
                        strcpy(buffer, valid + count + 1);
                        break;
                    }
                    count++;
                }

                if(add_line_after(tmp, para_num, line_num, buffer) == FAILURE){
                    fprintf(stdout, "add_line_after failed");
                }

            }

            else if(strcmp(command, "add_paragraph_after") == 0){
                i = sscanf(valid + strlen(command), "%d %s", &para_num, (char *)extra);

                if(isalpha(para_num) > 0 || para_num < 0 || i != 1){
                    fprintf(stdout, "Invalid Command\n");
                    continue;
                }

                if(add_paragraph_after(tmp, para_num) == FAILURE){
                    fprintf(stdout, "add_paragraph_after failed\n");
                }
            }

            else if(strcmp(command, "append_line") == 0){
                i = sscanf(valid + strlen(command), "%d %s", &para_num, buffer);

                if(i != 2 || isalpha(para_num) > 0 || para_num <= 0  || buffer[0] != '*'){
                    fprintf(stdout, "Invalid Command\n");
                    continue;
                }

                count = strlen(command);
                length = strlen(valid);
                while(count < length){
                    if(valid[count] == '*'){
                        strcpy(buffer, valid + count + 1);
                    }
                    count++;
                }

                if(append_line(tmp, para_num, buffer) == FAILURE){
                    fprintf(stdout, "append_line failed\n");
                }

            }

            
            else if(strcmp(command, "print_document") == 0){
                i = sscanf(valid + strlen(command), "%s", (char *)extra);

                if(i > 0){
                    fprintf(stdout, "Invalid Command\n");
                    continue;
                }
                
                if(print_document(tmp) == FAILURE){
                    fprintf(stdout, "print_document failed\n");
                }
            }
            
            else if(strcmp(command, "remove_line") == 0){
                i = sscanf(valid + strlen(command), "%d %d %s", &para_num, &line_num, (char *)extra);

                if(isalpha(para_num) > 0 || para_num <= 0 || isalpha(line_num) > 0 || line_num <= 0 || 
                    i != 2){
                    fprintf(stdout, "Invalid Command\n");
                    continue;
                }


                if(remove_line(tmp, para_num, line_num) == FAILURE){
                    fprintf(stdout, "remove_line failed\n");
                }
            }

            else if(strcmp(command, "load_file") == 0){
                i = sscanf(valid + strlen(command), "%s %d", buffer, (int *)extra);

                if(i != 1 || buffer == NULL){
                    fprintf(stdout, "Invalid Command");
                    continue;
                }

                if(load_file(tmp, buffer) == FAILURE){
                    fprintf(stdout, "load_file failed\n");
                }
            }

            else if(strcmp(command, "replace_text") == 0){
                i = sscanf(valid + strlen(command), "%s %s", buffer, buffer2);

                if(i != 2){
                    fprintf(stdout, "Invalid Command\n");
                    continue;
                }

                strcpy(buffer, valid + strlen(command) + 2);

                /* First buffer */
                strcpy(buffer2, buffer);
                strcpy(buffer, "");
                length = strlen(buffer);
                length = strlen(buffer2);
                i = 0;
                while(buffer2[i] != '\"'){
                    buffer[i] = buffer2[i];
                    buffer[i + 1] = '\0';
                    i++;
                }

                strcpy(buffer2, valid + strlen(command) + strlen(buffer) + 3);
            
                i = 0;
                count = 0;
                while(buffer2[count] != '\0'){
                    if(buffer2[count] == '\"'){
                        strcpy(buffer3, buffer2 + count + 1);
                        break;
                    }
                    count++;
                }
    
                strcpy(buffer2, buffer3);
                length = strlen(buffer2);
                buffer2[length - 2] = '\0';

                if(replace_text(tmp, buffer, buffer2) == FAILURE){
                    fprintf(stdout, "replace_text failed\n");
                }
            }

            else if(strcmp(command, "highlight_text") == 0){
                i = sscanf(valid + strlen(command), "%s", buffer);

                if(i != 1){
                    fprintf(stdout, "Invalid Command\n");
                    continue;
                }

                count = strlen(command);
                length = strlen(valid);
                while(count < length){
                    if(valid[count] == '\"'){
                        strcpy(buffer, valid + count + 1);
                        break;
                    }
                    count++;
                }
                length = strlen(buffer);
                buffer[length - 2] = '\0';

                highlight_text(tmp, buffer);
            }

            else if(strcmp(command, "remove_text") == 0){
                i = sscanf(valid + strlen(command), "%s", buffer);

                if(i != 1){
                    fprintf(stdout, "Invalid Command\n");
                    continue;
                }
                count = strlen(command);
                length = strlen(valid);
                while(count < length){
                    if(valid[count] == '\"'){
                        strcpy(buffer, valid + count + 1);
                        break;
                    }
                    count++;
                }
                length = strlen(buffer);
                buffer[length - 2] = '\0';

                remove_text(tmp, buffer);
            }

            else if(strcmp(command, "save_document") == 0){
                i = sscanf(valid + strlen(command), "%s %d", buffer, (int *)extra);

                if(i != 1 || buffer == NULL){
                    fprintf(stdout, "Invalid Command\n");
                    continue;
                }
               
                if(save_document(tmp, buffer) == FAILURE){
                    fprintf(stdout, "save_document failed\n");
                }
                
            }

            else if(strcmp(command, "reset_document") == 0){
                i = sscanf(valid + strlen(command), "%s", (char *)extra);

                if(i > 0){
                    fprintf(stdout, "Invalid Command\n");
                    continue;
                }

                reset_document(tmp);
            }

            else if(strcmp(command, "quit") == 0 || strcmp(command, "exit") == 0){
                i = sscanf(valid + strlen(command), "%s", (char *)extra);

                if(i > 0){
                    fprintf(stdout, "Invalid Command\n");
                    continue;
                }

                break;
            } else if(strstr(tmp_buff, "#") != NULL || i < 0){
                continue;
            } else {
                fprintf(stdout, "Invalid Command\n");
            }

        }
        
    fclose(user_input);
    return 0;
}