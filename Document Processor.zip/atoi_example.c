#include <stdio.h>
#include <stdlib.h>

void test(const char *str) {
   int x = atoi(str);

   printf("For \"%s\" we get %d\n", str, x);
}

int main(void) {
   test("Appartment 1 0");
   test("020");
   test("D8H9");
   test("9 7");
   test("-1");
   test("-78");
   test("-5.76");
   test("house");
   test("   ");

   return 0;
}
