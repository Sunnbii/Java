#include <stdio.h>
#include <stdlib.h> /* for system */

/* system() allows you to execute a shell 
 * command from within s C program 
 */

int main() {
  system("ls -al"); /* executing ls -al */

  return 0;
}
