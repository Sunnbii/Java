#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "document.h"

int init_document(Document *doc, const char *name){

    if(doc == NULL || name == NULL){
        return FAILURE;
    }

    if(strlen(name) > MAX_STR_SIZE){
        return FAILURE;
    }

    strcpy(doc->name, name);
    doc->number_of_paragraphs = 0;

    return SUCCESS;
}

int print_document(Document *doc){
    int col, row;
    Paragraph *para;

    if(doc == NULL){
        return FAILURE;
    }

    printf("Document name: \"%s\"\n", doc->name);
    printf("Number of Paragraphs: %d\n", doc->number_of_paragraphs);

    para = doc->paragraphs;
    for(col = 0; col < doc->number_of_paragraphs; col++){
        if(col != 0){
            printf("\n");
        }
        for(row = 0; row < para[col].number_of_lines; row++){
            printf("%s", para[col].lines[row]);
        }
    }

    return SUCCESS;
}

int reset_document(Document *doc){

    if(doc == NULL){
        return FAILURE;
    }

    doc->number_of_paragraphs = 0;

    return SUCCESS;
}

int add_paragraph_after(Document *doc, int paragraph_number){
    Paragraph para, tmp;
    int i;

    if(doc == NULL || doc->number_of_paragraphs == MAX_PARAGRAPHS || paragraph_number > doc->number_of_paragraphs){
        return FAILURE;
    }

    if(doc->number_of_paragraphs >= MAX_PARAGRAPHS || paragraph_number >= MAX_PARAGRAPHS){
        return FAILURE;
    }
    para.number_of_lines = 0;
    para.lines[0][0] = '\0';

    tmp = doc->paragraphs[paragraph_number];

   
    i = doc->number_of_paragraphs;
    
    doc->number_of_paragraphs++;

    if(paragraph_number < doc->number_of_paragraphs){
        while(i > paragraph_number){
            tmp = doc->paragraphs[i - 1];
            doc->paragraphs[i] = tmp;
            i--;
        }
        doc->paragraphs[paragraph_number] = para;
    } else {
         doc->paragraphs[paragraph_number] = para;
        
    }

    return SUCCESS;
}

int add_line_after(Document *doc, int paragraph_number, int line_number, const char *new_line){
    char tmp[MAX_STR_SIZE + 1];
    Paragraph *para;
    int i;

    if(doc == NULL || paragraph_number > doc->number_of_paragraphs){
        return FAILURE;
    }
    
    para = doc->paragraphs;

    if(paragraph_number > MAX_PARAGRAPHS){
        return FAILURE;
    }

    paragraph_number--;

    if(strlen(new_line) > MAX_STR_SIZE || para[paragraph_number].number_of_lines == MAX_PARAGRAPH_LINES){
        return FAILURE;
    }
    
	if(line_number < para[paragraph_number].number_of_lines){ 
        
	    for(i = para[paragraph_number].number_of_lines - 1; i >= line_number; i--){
            strcpy(tmp, para[paragraph_number].lines[i]); 
	        strcpy(para[paragraph_number].lines[i + 1], tmp); 
	    } 

        strcpy(para[paragraph_number].lines[line_number], new_line); 
	} else { 
	    strcpy(para[paragraph_number].lines[line_number], new_line); 
	} 
    para[paragraph_number].number_of_lines++;

    return SUCCESS;
}

int get_number_lines_paragraph(Document *doc, int paragraph_number, int *number_of_lines){

    if(doc == NULL || number_of_lines == NULL){
        return FAILURE;
    }

    if(doc->number_of_paragraphs < paragraph_number){
        return FAILURE;
    }

    *number_of_lines = doc->paragraphs[paragraph_number].number_of_lines;

    return SUCCESS;
}

static int remove_aux(const char *line, const char *string_to_replace, const char *replacement, 
    char *result_from_replacement){
        const char *tmp_line, *str;
        int tar_length;

        if(line == NULL || string_to_replace == NULL || replacement == NULL || result_from_replacement == NULL){
            return FAILURE;
        }

        tmp_line = line;
        tar_length = strlen(string_to_replace);
        result_from_replacement[0] = '\0';

        while((str = strstr(tmp_line, string_to_replace)) != NULL){
            strncat(result_from_replacement, tmp_line, str - tmp_line);

            strcat(result_from_replacement, replacement);

            tmp_line = str + tar_length;
        }
        strcat(result_from_replacement, tmp_line);

        return SUCCESS;
}

int remove_text(Document *doc, const char *target){
    int para_num = 0, line_num = 0;
    Paragraph *para;
    char result[MAX_STR_SIZE + 1];

    if(doc == NULL || target == NULL){
        return FAILURE;
    }

    para = doc->paragraphs;

    while(para_num < doc->number_of_paragraphs){
        line_num = 0;

        while(line_num < para[para_num].number_of_lines){
            remove_aux(para[para_num].lines[line_num], target, "", result);
            strcpy(para[para_num].lines[line_num], result);

            line_num++;
        }
        para_num++;
    }

    return SUCCESS;
}

int remove_line(Document *doc, int paragraph_number, int line_number){
    int index;
    Paragraph *para;

    if(doc == NULL){
        return FAILURE;
    }

    para = doc->paragraphs;

    if(para[paragraph_number - 1].number_of_lines < line_number || doc->number_of_paragraphs < paragraph_number){
        return FAILURE;
    }

    if(line_number > 0){
        line_number--;
    }
    
    if(paragraph_number > 0){
        paragraph_number--;
    }

    /* remove first */
    strcpy(para[paragraph_number].lines[line_number], "");

    for(index = 0; index < para[paragraph_number].number_of_lines; index++){

        if(strcmp(para[paragraph_number].lines[index], "") == 0){
            /* Shifts everything up so there isn't an empty gap */
            
            if((index + 1) < para[paragraph_number].number_of_lines){
                strcpy(para[paragraph_number].lines[index], para[paragraph_number].lines[index + 1]);
                strcpy(para[paragraph_number].lines[index + 1], "");
            }
        }
    }
    para[paragraph_number].number_of_lines--;

    return SUCCESS;
}

int append_line(Document *doc, int paragraph_number, const char *new_line){
    Paragraph *para;

    if(doc == NULL){
        return FAILURE;
    }

    para = doc->paragraphs;

    paragraph_number--;
    if(paragraph_number < 0 || paragraph_number > MAX_PARAGRAPHS || para[paragraph_number].number_of_lines >= MAX_PARAGRAPH_LINES){
        return FAILURE;
    }

    strcpy(para[paragraph_number].lines[para[paragraph_number].number_of_lines], new_line);
    para[paragraph_number].number_of_lines++;

    return SUCCESS;
}

int load_document(Document *doc, char data[][MAX_STR_SIZE + 1], int data_lines){
    Paragraph *para;
    int para_num = 0, line = 0, i = 0, count, added_paras = 1;

    if(doc == NULL || data == NULL || data_lines <= 0){
        return FAILURE;
    }

    for(count = 0; count < data_lines; count++){
        if(strcmp(data[count], "") == 0){
            added_paras++;
        }
    }

    for(count = doc->number_of_paragraphs - 1; count >= 0; count--){
        doc->paragraphs[count + added_paras] = doc->paragraphs[count];
    }

    doc->number_of_paragraphs++;
    para = doc->paragraphs;
    
    /* Going through dara array */
    while(i < data_lines){
        /* Find empty strings */
        if(strcmp(data[i], "") == 0){
            doc->number_of_paragraphs++;
            para_num++;
            line = 0;

        } else {
            strcpy(para[para_num].lines[line], data[i]);
            para[para_num].number_of_lines = line + 1;
            line++;
        }
        
        i++;
    }

    return SUCCESS;
}

static int replace_text_in_line(const char *line, const char *string_to_replace, const char *replacement, 
    char *result_from_replacement){
        const char *tmp_line, *str;
        int tar_length;

        if(line == NULL || string_to_replace == NULL || replacement == NULL || result_from_replacement == NULL){
            return FAILURE;
        }

        tmp_line = line;
        tar_length = strlen(string_to_replace);
        result_from_replacement[0] = '\0';

        while((str = strstr(tmp_line, string_to_replace)) != NULL){
            strncat(result_from_replacement, tmp_line, str - tmp_line);

            strcat(result_from_replacement, replacement);

            tmp_line = str + tar_length;
        }
        strcat(result_from_replacement, tmp_line);

        return SUCCESS;
}

int replace_text(Document *doc, const char *target, const char *replacement){
    int para_num, line;
    Paragraph *para;
    char result[MAX_STR_SIZE + 1];

    if(doc == NULL || target == NULL || replacement == NULL){
        return FAILURE;
    }

    para = doc->paragraphs;

    for(para_num = 0; para_num < doc->number_of_paragraphs; para_num++){
        //printf("Here\n");
        for(line = 0; line < para[para_num].number_of_lines; line++){
            replace_text_in_line(para[para_num].lines[line], target, replacement, result);
            strcpy(para[para_num].lines[line], result);
        }
    }

    return SUCCESS;
}


static int highlight_aux(const char *line, const char *string_to_replace, const char *replacement, 
    char *result_from_replacement){
        const char *tmp_line, *str;
        int tar_length;

        if(line == NULL || string_to_replace == NULL || replacement == NULL || result_from_replacement == NULL){
            return FAILURE;
        }

        tmp_line = line;
        tar_length = strlen(string_to_replace);
        result_from_replacement[0] = '\0';

        while((str = strstr(tmp_line, string_to_replace)) != NULL){
            strncat(result_from_replacement, tmp_line, str - tmp_line);

            strcat(result_from_replacement, replacement);

            tmp_line = str + tar_length;
        }
        strcat(result_from_replacement, tmp_line);

        return SUCCESS;
}

int highlight_text(Document *doc, const char *target){
    int paragraph, line;
    Paragraph *para;
    char tmp[MAX_STR_SIZE + 1], result[MAX_STR_SIZE + 1];

    if(doc == NULL || target == NULL){
        return FAILURE;
    }

    para = doc->paragraphs;
    strcpy(tmp, HIGHLIGHT_START_STR);
    strcpy(tmp + 1, target);
    strcpy(tmp + strlen(tmp), HIGHLIGHT_END_STR);

    for(paragraph = 0; paragraph < doc->number_of_paragraphs; paragraph++){

        for(line = 0; line < doc->paragraphs[paragraph].number_of_lines; line++){

            highlight_aux(para[paragraph].lines[line], target, tmp, result);
            strcpy(para[paragraph].lines[line], result);

            /*if(strcmp(para[paragraph].lines[line], target) == 0){
                strcpy(para[paragraph].lines[line], tmp);
            }*/
        }
    }

    return SUCCESS;
}

int load_file(Document *doc, const char *filename){
    FILE *file;
    int p = 0, l = 0;
    Paragraph *para;

    if(doc == NULL || filename == NULL){
        return FAILURE;
    }

    file = fopen(filename, "r");

    if(file == NULL){
        return FAILURE;
    }
    add_paragraph_after(doc, p);
    para = doc->paragraphs;
    
    while(fgets(para[p].lines[l], MAX_STR_SIZE + 1, file) != NULL){
        if(isspace(para[p].lines[l][0]) > 0){
            strcpy(para[p].lines[l], "");
            p++;
            add_paragraph_after(doc, p);
            l = 0;
            continue;
            }

        add_line_after(doc, p + 1, l, para[p].lines[l]);
        l++;
    }
    
    fclose(file);
    return SUCCESS;
}

int save_document(Document *doc, const char *filename){
    FILE *file;
    Paragraph *para;
    int p, l;

    if(doc == NULL || filename == NULL){
        return FAILURE;
    }

    file = fopen(filename, "w");
    if(file == NULL){
        return FAILURE;
    }
    para = doc->paragraphs;

    if(file == NULL){
        return FAILURE;
    }

    for(p = 0; p < doc->number_of_paragraphs; p++){
        if(p != 0){
            fprintf(file, "\n");
        }
        for(l = 0; l < para[p].number_of_lines; l++){
            fprintf(file, "%s", para[p].lines[l]);
        }
        
    }
    fclose(file);
    return SUCCESS;
}